using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Control : MonoBehaviour
{
    
    // Start is called before the first frame update
    public float speed = 4;
    public Text scoreText;
    public Text winText;
    public Button restartButton;
    public AudioSource triggerAudio;
    public AudioSource winAudio;
    private Rigidbody rigidbody;
    private int score = 0;
  
    void Start()
    {
        rigidbody = this.GetComponent<Rigidbody>();
        winText.gameObject.SetActive(false);
        restartButton.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        float moveH = Input.GetAxis("Horizontal");
        float moveV = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveH, 0, moveV);
        rigidbody.AddForce(movement * speed);
    }
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Player OnTriggerEnter");
        if (other.gameObject.CompareTag("Coin"))
        {
            other.gameObject.SetActive(false);
            triggerAudio.Play();
            score = score + 5;
            scoreText.text = "Score :" + score.ToString();
            if(score == 30)
            {
                winText.gameObject.SetActive(true);
                restartButton.gameObject.SetActive(true);
                winAudio.Play();
            }
        }
    }

}
